﻿#include <unordered_set>

// C 스타일 코드 - typedef 
typedef int DWORD;
typedef void(*F)(); 

int main()
{
	DWORD n; 
	F     f; 
}
