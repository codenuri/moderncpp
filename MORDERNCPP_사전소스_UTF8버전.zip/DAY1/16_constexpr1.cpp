﻿// 16_constexpr1
int main()
{
	int n = 10;
	const int c1 = 10; 
	const int c2 = n;  

	// 다음중 에러를 모두 고르세요
	int arr1[10]; 
	int arr2[n ]; 
	int arr3[c1]; 
	int arr4[c2]; 

}
