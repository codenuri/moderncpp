﻿// 143 
#include <functional>

int main()
{
	// 람다표현식을 담는 방법

	auto f1 = [](int a, int b) { return a + b; };
}
