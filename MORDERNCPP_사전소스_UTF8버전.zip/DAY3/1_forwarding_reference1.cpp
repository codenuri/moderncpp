﻿
// forwarding reference 란 ?
// => "T&&" 템플릿

template<typename T> void chronomety(T&& a)
{
}

int main()
{

}
