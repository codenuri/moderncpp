﻿#include <string>
#include <iostream>

class People
{
	std::string name;
public:
	People(const std::string& n)
	{
		name = n;
	}
};

int main()
{
	std::string s1("kim");

	People p(s1);
}
