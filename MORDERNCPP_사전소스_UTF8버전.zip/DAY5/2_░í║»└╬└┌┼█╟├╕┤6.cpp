﻿#include <iostream>

// 233 page 입니다.

template<typename ... Types>
void foo(Types ... args)
{

}

int main()
{
	foo(1, 3.4, 'A'); 
}





