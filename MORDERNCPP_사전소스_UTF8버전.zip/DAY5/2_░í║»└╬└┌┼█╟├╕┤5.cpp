﻿#include <iostream>
#include <tuple>

template<typename ... Types> void foo(Types ... args)
{
	// args 에 있는 모든 요소를 꺼내고 싶다면

}


int main()
{
	foo(1, 2, 3);
}

