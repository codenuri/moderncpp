// 3_�κ�Ư��ȭ1 - 156 p
#include <iostream>


// primary template
template<typename T> class Stack 
{
public:
	// ��� �Լ��� 10���϶�
	void push(T a) { std::cout << "T" << std::endl; }
};

// partial specialization( �κ� Ư��ȭ)
template<typename T> class Stack<T*>
{
public:
	// 5��
	void push(T* a) { std::cout << "T*" << std::endl; }
};

// specialization(Ư��ȭ)
template<> class Stack<char*>
{
public:
	void push(char* a) { std::cout << "char*" << std::endl; }
};


int main()
{
	Stack<int>   s1; s1.push(0);
//	Stack<int*>  s2; s2.push(0);
//	Stack<char*> s3; s3.push(0);
}