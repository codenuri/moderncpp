#include <iostream>
#include <vector>
#include "chronometry.h"

bool is_odd(int n) { return n % 2 == 1; }

constexpr int size = 100'000'000;
std::vector<int> v1(size, 0);
std::vector<int> v2(size, 0);

void init()
{
	v1[size - 1] = 1;
	v2[size - 1] = 1;
}

void ex1()
{
	auto ret = std::find_if(v1.begin(), v1.end(), is_odd);
}
void ex2()
{
	auto ret = std::find_if(v2.begin(), v2.end(), [](int n) { return n % 2 == 1; });
}

int main()
{
	init();

	chronometry(ex1);
	chronometry(ex2);
	chronometry(ex1);
	chronometry(ex2);
}