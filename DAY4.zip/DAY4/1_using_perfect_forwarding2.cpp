#include <iostream>

class Point
{
	int x, y;
public:
	Point(int a, int b) { std::cout << "Point()" << std::endl; }
	~Point() { std::cout << "~Point()" << std::endl; }
	Point(const Point&) { std::cout << "copy ctor" << std::endl; }
};

template<typename T>
class Vector
{
	T* buffer;
public:
	
};

int main()
{
	Vector<Point> v;

	Point pt{ 1,1 };
	v.push_back(pt);
	v.push_back(std::move(pt));

	v.emplace_back(1, 1);
}