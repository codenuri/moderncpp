﻿#include <string>
#include "cppmaster.h"

// value_category - 109 page

// expression 의 결과로 최종적으로 만들어지는 값이 가지는 2가지 속성
// 1. type
// 2. value category ( lvalue, xvalue, prvalue )

struct Object
{
	std::string name = "kim";
	Object() = default;
	Object(const Object&)     { std::cout << "copy\n"; }
	Object(Object&&) noexcept { std::cout << "move\n"; }
};


int main()
{
	Object obj;
	
	Object{};

	static_cast<Object&&>(obj);

	static_cast<Object>(obj);
}
