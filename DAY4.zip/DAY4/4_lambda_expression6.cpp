﻿#include <iostream>
#include <vector>
#include <functional>

int main()
{
	// #1. 람다표현식을 담는 방법
	auto f1 = [](int a, int b){ return a + b; };



	// #2. 람다표현식과 컨테이너
}

