#include <iostream>

// ���� ǥ���� - 125page

int add(int a, int b) { return a + b; }

void foo(int(*f)(int, int))
{
	int ret = f(1, 2);
}

int main()
{
	foo( add );

}
