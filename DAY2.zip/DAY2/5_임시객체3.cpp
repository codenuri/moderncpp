﻿// 77 page
#include <iostream>

class Point
{
public:
	int x, y;
	Point(int a, int b) :x{ a }, y{ b } {  }
};

// 임시객체와 함수 인자 - 81 page

void draw_line(const Point& from, const Point& to) {}
void init(Point& pt) { pt.x = 0; pt.y = 0; }

int main()
{
	// (0, 0) ~ (5,5) 의 위치에 선을 그리고 싶다.

	// #1. 2개의 객체를 생성후에 전달
	Point from{ 0,0 };
	Point to{ 5,5 };

	draw_line(from, to);

	// #2.


}





