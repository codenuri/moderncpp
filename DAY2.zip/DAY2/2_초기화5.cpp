﻿#include <vector>
#include <string>
#include <memory>

void goo(std::vector<int> v) {}
void hoo(std::string s) {}

int main()
{
	// 아래 코드에 대해서 생각해 보세요
	hoo("hello");
	std::string s1("hello");
	std::string s2 = "hello";

	goo(10);
	std::vector<int> v1(10);  
	std::vector<int> v2 = 10; 
}





