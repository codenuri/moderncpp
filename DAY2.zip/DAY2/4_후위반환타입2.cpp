﻿// 73 page
#include <iostream>

template<typename T1>
T1 Mul(T1 a, T1 b)
{
	return a * b;
}

int main()
{
	std::cout << Mul(3, 4.1)   << std::endl;
}

