﻿#include <iostream>

template<typename T> void foo(T a)
{
	a = 100;
}
int main()
{
	// #1. 타입 인자를 명시적으로 전달하는 경우
	foo<int>(3.4);

	// #2. 타입 인자를 전달하지 않는 경우.
	foo(10); // T : 
	foo(3.4);// T : ?

	int n = 10;
	int& r = n;
	const int c = 10;
	const int& cr = c;
	
	foo(n); 
	foo(c); 
	foo(r); 
	foo(cr);
}
