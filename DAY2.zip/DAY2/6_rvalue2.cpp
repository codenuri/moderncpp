﻿// lvalue, rvalue 는 변수에 부여 되는 특징이 아니라
// => expression에 부여되는 특징

// statement : ; 으로 끝나는 한줄의 코드. 실행단위
// expression : 한개의 값을 만드는 코드 집합

int main()
{
	int n = 0;

	n * 2 + 3 - 2;

	
}
