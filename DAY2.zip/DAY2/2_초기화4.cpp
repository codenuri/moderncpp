﻿// 58 page
class Vector
{
	int sz;
public:
	Vector(int s) : sz(s) {}
};
void foo(Vector v) {} 				  

int main()
{
	// #1. 인자가 한개인 생성자가 있다면 아래 처럼 사용가능
	Vector v1(10); 
	Vector v2 = 10; 
	Vector v3{ 10 };
	Vector v4 = { 10 };

	//----------------
	foo(10); // ?
}







