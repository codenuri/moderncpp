﻿#include <iostream>

class Point
{
	int x;
	int y;
public:
	Point(int x = 0, int y = 0) : x{ x }, y{ y } {}
};

void f1(int n) {}
void f2(Point pt) {}

int main()
{
	f1(3);
}

Point f3() { }

