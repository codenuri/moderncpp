﻿// 후위 반환 타입 -  73 page

int square(int a)
{
	return a * a;
}

int main()
{
	square(3);
}
