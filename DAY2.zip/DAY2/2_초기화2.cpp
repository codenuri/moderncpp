﻿#include <complex>

int main()
{
	int n1 = 10;
	int x1[2] = { 1,2 };
	std::complex<double> c1(1, 2);
}












