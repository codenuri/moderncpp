﻿// 필드 초기화 - 55 page
#include <iostream>

class Point
{
	// member field initialization
	int x = 0;
	int y = 0;
public:
	Point() {}
	Point(int x) : x(x) {}
	Point(int x, int y) : x(x), y(y) {}
};

int main()
{
}
