﻿// 4_rvalue - 87 page
int x = 0;
int  foo() { return x;}
int& goo() { return x; }

int main()
{
	int v1 = 0, v2 = 0;
	
	v1 = 10;
	10 = v1;
	v2 = v1;


	int* p1 = &v1;
	int* p2 = &10; 
}









