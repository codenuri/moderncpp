﻿int main()
{
	int  n1 = 3.4; 
	char c1 = 500; 

	// prevent narrow - 56 page 
	int n2{ 3.4 };  
	char c2{ 500 }; 

}
