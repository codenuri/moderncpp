﻿#include <iostream>

// #2. 인자가 "참조" 타입 일때

template<typename T> void foo(T a)
{
	a = 100;
}

int main()
{
	int n = 10;
	int& r = n;
	const int c = 10;
	const int& cr = c;

	foo(n);
	foo(c);
	foo(r);
	foo(cr);
}
