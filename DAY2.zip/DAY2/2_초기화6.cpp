﻿// 초기화 용어 - 60 page
#include <iostream>

struct Point
{
	int x;
	int y;
};

int main()
{
	int n1{ 0 };	
	int n2 = { 0 }; 
	int n3;			
	int n4{};		

	std::cout << n4 << std::endl; // 0

	Point pt{}; 
	std::cout << pt.x << std::endl;
}


