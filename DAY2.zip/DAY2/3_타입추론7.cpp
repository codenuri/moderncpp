﻿template<typename T> void f1(T a,  T b)  {}
template<typename T> void f2(T& a, T& b) {}

int main()
{
	int x[3] = { 1,2,3 };

	// 아래 코드에서 a1, a2 의 타입은 ?
	auto  a1 = x;
	auto& a2 = x;


	// 아래 코드에서 에러를 찾아 보세요
	f1("apple", "orange");
	f2("apple", "orange");
}
