//8_nullptr3
#include <iostream>

int main()
{
	// literal �� Ÿ��
	3;
	3.4;
	"hello";
	false;
	nullptr;
}



