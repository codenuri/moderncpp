﻿// 빌드 하는 법
// Ctrl + F5

int main()
{
	int n1 = 0;

	auto a1 = 3;
	auto a2 = 3.4;
}
