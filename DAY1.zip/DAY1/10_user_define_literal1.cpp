int main()
{
	auto n1 = 0x10ll;

	float f = 3.4f;
}




