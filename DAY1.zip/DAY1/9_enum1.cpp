// 9_enum - 32 page

enum COLOR { red = 1, green, blue};

int main()
{
	COLOR c1 = COLOR::red;
	int c2 = COLOR::red;
	int c3 = red;

	int red = 100;
	int n = red; // ?
}





