int main()
{
	int n = 3;

	const int c1 = n;
	const int c2 = 3;

	constexpr int c3 = n;
	constexpr int c4 = 3;
}