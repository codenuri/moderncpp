#include <iostream>

int main()
{
	// 64bit 환경에서만 동작가능한 코드
}