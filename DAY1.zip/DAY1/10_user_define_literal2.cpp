// 10_user_define_literal2
#include <iostream>
#include <string>
#include <chrono>
#include <thread>
using namespace std::chrono; 

void foo(const char* s) { std::cout << "char*\n"; }
void foo(std::string s) { std::cout << "string\n"; }

int main()
{
	foo("hello");
	foo("hello");
				
}


