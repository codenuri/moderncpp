#include <iostream>

// parameter pack, sizeof...

template<typename ... Types> void foo(Types ... args)
{
	
}

int main()
{
	foo(1, 2, 3);
}