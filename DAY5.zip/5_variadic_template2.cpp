template<typename T> void f1(T arg)
{
}

int main()
{
	f1(1);
	f1(3.4);
}