
int& foo(int& r) { return r; }


template<typename F, typename T>
void chronometry(F f, T&& arg)
{
	f(std::forward<T>(arg));
}


int main()
{
	int n = 3;

	chronometry(foo, n); // foo(n)
}