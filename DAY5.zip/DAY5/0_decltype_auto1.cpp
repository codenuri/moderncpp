
int& foo(int& r) { return r; }

int main()
{
	int n = 3;

	auto ret = foo(n);
}