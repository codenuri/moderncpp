﻿#include <iostream>
#include <type_traits>

int main()
{
	int n = 10;

	(n + 3) = 10;
	(n = 3) = 10;

}
