﻿#include <iostream>

template<typename Type> 
void foo(Type arg)
{

}

int main()
{
	foo(1, 3.4, 'A');
	foo(1, 2, 3);
}
