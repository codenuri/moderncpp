// add.h
#pragma once

void foo();

int add(int a, int b);

