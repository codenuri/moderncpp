// add.cpp
#include <iostream>

int add(int a, int b)
{
	std::cout << "add\n";
	return a + b;
}

void foo()
{

}