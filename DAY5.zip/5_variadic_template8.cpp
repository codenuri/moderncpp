#include <iostream>

// recursive ? - 233page

template<typename ... Types>
void foo(Types ... args)
{

}

int main()
{
	foo(1, 3.4, 'A'); 
}





