#include <iostream>
#include <type_traits>

#define print_value_category(...)	\
	if ( std::is_lvalue_reference_v<decltype( (__VA_ARGS__))>)	\
		printf("[ %s ] is lvalue\n", #__VA_ARGS__);				\
	else  if ( std::is_rvalue_reference_v<decltype((__VA_ARGS__))>)	\
		printf("[ %s ] is rvalue(xvalue)\n", #__VA_ARGS__);			\
	else \
		printf("[ %s ] is rvalue(prvalue)\n", #__VA_ARGS__);			

int main()
{
	int n = 0;
	print_value_category(n);
	print_value_category(n = 3);
	print_value_category(n+1);
	print_value_category(++n);
	print_value_category(n++);

}