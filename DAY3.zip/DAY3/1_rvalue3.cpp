// 1_rvalue - 87 page
int x = 0;
int  foo() { return x; }
int& goo() { return x; }

int main()
{
	int n = 3;

	int* p1 = &n;
	int* p2 = &3;

	foo() = 5;
	goo() = 5;

	const int c = 0;
	c = 10; // error
}









