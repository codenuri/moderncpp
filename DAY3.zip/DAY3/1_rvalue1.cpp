﻿// 1_rvalue - 87 page
int main()
{
	int v1 = 10, v2 = 10;
	v1 = 20;
	10 = v1;
}









